export const ASSIGN_NOTES = '@/notes/ASSIGN_NOTES';

export const ASSIGN_CODES = '@/codes/ASSIGN_CODES';